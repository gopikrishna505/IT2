import { useState, useRef, useEffect, useCallback } from "react";

const SYSTEM = `You are IT², a professional coding AI. Write clean code with markdown fences. If user writes in Telugu, respond in Telugu. When files are shared, analyze them thoroughly.`;

// ── Theme ────────────────────────────────────────────────────────────────────
const L = {
  bg: "#fafaf8", sf: "#f3f2ee", bd: "#e5e4e0",
  tx: "#1a1a1a", s2: "#4a4a4a", mt: "#9a9a9a",
  ac: "#1a1a1a", af: "#ffffff",
  inp: "#ffffff", inpBd: "#dddcda",
  msgUser: "#ffffff", msgAI: "#f3f2ee",
  shadow: "rgba(0,0,0,0.06)"
};
const D = {
  bg: "#0f0f0f", sf: "#181818", bd: "#252525",
  tx: "#ededed", s2: "#a0a0a0", mt: "#505050",
  ac: "#ededed", af: "#111111",
  inp: "#181818", inpBd: "#2e2e2e",
  msgUser: "#1e1e1e", msgAI: "#141414",
  shadow: "rgba(0,0,0,0.3)"
};

// ── Helpers ──────────────────────────────────────────────────────────────────
const isImg  = f => f.type.startsWith("image/");
const isPDF  = f => f.type === "application/pdf";
const isCode = f => f.name.match(/\.(py|js|ts|jsx|tsx|java|c|cpp|go|sql|json|html|css|txt|csv|rs|sh)$/i);
const toB64  = f => new Promise((ok,er)=>{const r=new FileReader();r.onload=()=>ok(r.result.split(",")[1]);r.onerror=er;r.readAsDataURL(f);});
const toTxt  = f => new Promise((ok,er)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=er;r.readAsText(f);});

function playBeep(){
  try{
    const ctx=new(window.AudioContext||window.webkitAudioContext)();
    const o=ctx.createOscillator(),g=ctx.createGain();
    o.connect(g);g.connect(ctx.destination);
    o.frequency.value=660;o.type="sine";
    g.gain.setValueAtTime(0.2,ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.35);
    o.start();o.stop(ctx.currentTime+0.35);
  }catch(e){}
}

// ── Inline formatter ─────────────────────────────────────────────────────────
function fmt(text, c) {
  const out=[], re=/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g;
  let last=0,m,i=0;
  while((m=re.exec(text))!==null){
    if(m.index>last)out.push(text.slice(last,m.index));
    const v=m[0];
    if(v[0]==="`")out.push(
      <code key={i++} style={{background:c.bd,padding:"2px 6px",borderRadius:4,fontFamily:"'JetBrains Mono',monospace",fontSize:"0.85em",color:c.tx,letterSpacing:"-0.3px"}}>
        {v.slice(1,-1)}
      </code>
    );
    else if(v.startsWith("**"))out.push(<strong key={i++} style={{color:c.tx,fontWeight:600}}>{v.slice(2,-2)}</strong>);
    else out.push(<em key={i++} style={{color:c.s2,fontStyle:"italic"}}>{v.slice(1,-1)}</em>);
    last=m.index+m[0].length;
  }
  if(last<text.length)out.push(text.slice(last));
  return out;
}

// ── Code Block ───────────────────────────────────────────────────────────────
function CodeBlock({lang,code,c}){
  const [cop,setCop]=useState(false);
  const [out,setOut]=useState(null);
  const [running,setRunning]=useState(false);
  const isJS=["js","javascript"].includes(lang.toLowerCase());
  const isPy=["python","py"].includes(lang.toLowerCase());

  const copy=()=>{navigator.clipboard.writeText(code);setCop(true);setTimeout(()=>setCop(false),2000);};
  const run=async()=>{
    setRunning(true);setOut(null);
    if(isJS){
      setTimeout(()=>{
        try{const logs=[];new Function("console",code)({log:(...a)=>logs.push(a.map(String).join(" ")),error:(...a)=>logs.push("ERR: "+a.join(" "))});setOut({ok:true,text:logs.join("\n")||"(no output)"});}
        catch(e){setOut({ok:false,text:e.message});}
        setRunning(false);
      },80);
    }else if(isPy){
      try{
        if(!window._py){setOut({ok:true,text:"⏳ loading python..."});const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/pyodide/v0.25.1/full/pyodide.js";document.head.appendChild(s);await new Promise(r=>{s.onload=r;});window._py=await window.loadPyodide();}
        let o="";window._py.setStdout({batched:s=>{o+=s+"\n";}});window._py.setStderr({batched:s=>{o+="ERR: "+s+"\n";}});
        await window._py.runPythonAsync(code);setOut({ok:true,text:o.trim()||"(no output)"});
      }catch(e){setOut({ok:false,text:e.message});}
      setRunning(false);
    }
  };

  return(
    <div style={{margin:"14px 0",borderRadius:10,overflow:"hidden",border:"1px solid "+c.bd,boxShadow:"0 2px 8px "+c.shadow}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",background:c.sf,padding:"7px 14px",borderBottom:"1px solid "+c.bd}}>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:c.mt,letterSpacing:"0.5px",textTransform:"uppercase"}}>{lang}</span>
        <div style={{display:"flex",gap:6}}>
          {(isJS||isPy)&&(
            <button onClick={run} disabled={running}
              style={{background:"none",border:"1px solid "+c.bd,color:c.s2,padding:"3px 10px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"inherit",transition:"all 0.15s"}}
              onMouseEnter={e=>{e.currentTarget.style.background=c.bd;}}
              onMouseLeave={e=>{e.currentTarget.style.background="none";}}>
              {running?"…":"▶ run"}
            </button>
          )}
          <button onClick={copy}
            style={{background:"none",border:"1px solid "+c.bd,color:cop?"#16a34a":c.mt,padding:"3px 10px",borderRadius:5,cursor:"pointer",fontSize:11,fontFamily:"inherit",transition:"all 0.15s"}}
            onMouseEnter={e=>{if(!cop)e.currentTarget.style.background=c.bd;}}
            onMouseLeave={e=>{e.currentTarget.style.background="none";}}>
            {cop?"✓ copied":"copy"}
          </button>
        </div>
      </div>
      <pre style={{background:c.sf,padding:"16px",overflowX:"auto",fontFamily:"'JetBrains Mono',monospace",fontSize:13,lineHeight:1.75,color:c.tx,margin:0,letterSpacing:"-0.2px"}}><code>{code}</code></pre>
      {out&&(
        <div style={{background:c.bg,borderTop:"1px solid "+c.bd,padding:"10px 16px",fontFamily:"'JetBrains Mono',monospace",fontSize:12,color:out.ok?"#16a34a":"#dc2626",whiteSpace:"pre-wrap",lineHeight:1.6}}>
          {out.text}
        </div>
      )}
    </div>
  );
}

// ── Markdown renderer ─────────────────────────────────────────────────────────
function MD({text,c}){
  const lines=text.split("\n"),els=[];
  let i=0,ki=0;
  const k=()=>ki++;
  while(i<lines.length){
    const l=lines[i];
    if(l.startsWith("```")){
      const lang=l.slice(3).trim()||"code",code=[];
      i++;while(i<lines.length&&!lines[i].startsWith("```")){code.push(lines[i]);i++;}
      els.push(<CodeBlock key={k()} lang={lang} code={code.join("\n")} c={c}/>);
      i++;continue;
    }
    if(l.startsWith("### ")){els.push(<h3 key={k()} style={{fontSize:15,fontWeight:600,margin:"16px 0 4px",color:c.tx,letterSpacing:"-0.3px"}}>{fmt(l.slice(4),c)}</h3>);i++;continue;}
    if(l.startsWith("## ")) {els.push(<h2 key={k()} style={{fontSize:17,fontWeight:600,margin:"18px 0 5px",color:c.tx,letterSpacing:"-0.4px"}}>{fmt(l.slice(3),c)}</h2>);i++;continue;}
    if(l.startsWith("# "))  {els.push(<h1 key={k()} style={{fontSize:20,fontWeight:700,margin:"20px 0 6px",color:c.tx,letterSpacing:"-0.5px"}}>{fmt(l.slice(2),c)}</h1>);i++;continue;}
    if(l.match(/^[-*] /)){
      const items=[];
      while(i<lines.length&&lines[i].match(/^[-*] /)){items.push(<li key={k()} style={{lineHeight:1.85,color:c.s2,marginBottom:2}}>{fmt(lines[i].slice(2),c)}</li>);i++;}
      els.push(<ul key={k()} style={{paddingLeft:20,margin:"8px 0",listStyleType:"disc"}}>{items}</ul>);continue;
    }
    if(l.match(/^\d+\. /)){
      const items=[];
      while(i<lines.length&&lines[i].match(/^\d+\. /)){items.push(<li key={k()} style={{lineHeight:1.85,color:c.s2,marginBottom:2}}>{fmt(lines[i].replace(/^\d+\. /,""),c)}</li>);i++;}
      els.push(<ol key={k()} style={{paddingLeft:20,margin:"8px 0"}}>{items}</ol>);continue;
    }
    if(l.match(/^---+$/)){els.push(<hr key={k()} style={{border:"none",borderTop:"1px solid "+c.bd,margin:"14px 0"}}/>);i++;continue;}
    if(l.trim()===""){els.push(<div key={k()} style={{height:8}}/>);i++;continue;}
    els.push(<p key={k()} style={{margin:"4px 0",lineHeight:1.85,color:c.s2}}>{fmt(l,c)}</p>);
    i++;
  }
  return <>{els}</>;
}

// ── Login ────────────────────────────────────────────────────────────────────
function Login({onLogin,c}){
  const [email,setEmail]=useState("");
  const [pass,setPass]=useState("");
  const [name,setName]=useState("");
  const [isNew,setIsNew]=useState(false);
  const [err,setErr]=useState(false);

  const go=()=>{
    if(!email||!pass){setErr(true);return;}
    const db=JSON.parse(localStorage.getItem("it2db")||"{}");
    if(isNew){
      if(db[email]){setErr(true);return;}
      db[email]={name:name||email.split("@")[0],pass};
      localStorage.setItem("it2db",JSON.stringify(db));
      onLogin({email,name:name||email.split("@")[0]});
    }else{
      if(!db[email]||db[email].pass!==pass){setErr(true);return;}
      onLogin({email,name:db[email].name});
    }
  };

  const inp={
    background:c.inp, border:"1px solid "+(err?"#ef4444":c.inpBd),
    borderRadius:10, padding:"11px 15px", color:c.tx, fontSize:15,
    width:"100%", outline:"none", fontFamily:"inherit", transition:"border-color 0.2s",
    letterSpacing:"-0.1px"
  };

  return(
    <div style={{height:"100dvh",display:"flex",alignItems:"center",justifyContent:"center",background:c.bg,padding:"0 24px"}}>
      <div style={{width:"100%",maxWidth:340,animation:"slideUp 0.4s cubic-bezier(0.16,1,0.3,1)"}}>

        {/* Logo */}
        <div style={{textAlign:"center",marginBottom:36}}>
          <div style={{width:48,height:48,borderRadius:14,background:c.ac,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 12px",boxShadow:"0 4px 16px "+c.shadow}}>
            <span style={{color:c.af,fontSize:20,fontWeight:700,fontFamily:"'JetBrains Mono',monospace",letterSpacing:"-1px"}}>IT²</span>
          </div>
          <p style={{color:c.mt,fontSize:14,letterSpacing:"-0.2px"}}>AI Coding Assistant</p>
        </div>

        {/* Tab */}
        <div style={{display:"flex",background:c.sf,border:"1px solid "+c.bd,borderRadius:10,padding:3,marginBottom:14}}>
          <button onClick={()=>{setIsNew(false);setErr(false);}}
            style={{flex:1,background:!isNew?c.bg:"transparent",border:"none",color:!isNew?c.tx:c.mt,padding:"8px",borderRadius:7,cursor:"pointer",fontSize:14,fontWeight:!isNew?500:400,fontFamily:"inherit",transition:"all 0.2s",letterSpacing:"-0.2px"}}>
            Sign in
          </button>
          <button onClick={()=>{setIsNew(true);setErr(false);}}
            style={{flex:1,background:isNew?c.bg:"transparent",border:"none",color:isNew?c.tx:c.mt,padding:"8px",borderRadius:7,cursor:"pointer",fontSize:14,fontWeight:isNew?500:400,fontFamily:"inherit",transition:"all 0.2s",letterSpacing:"-0.2px"}}>
            Sign up
          </button>
        </div>

        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {isNew&&<input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} style={inp}
            onFocus={e=>e.target.style.borderColor=c.tx} onBlur={e=>e.target.style.borderColor=err?"#ef4444":c.inpBd}/>}
          <input type="email" placeholder="Email" value={email} onChange={e=>{setEmail(e.target.value);setErr(false);}} style={inp}
            onFocus={e=>e.target.style.borderColor=c.tx} onBlur={e=>e.target.style.borderColor=err?"#ef4444":c.inpBd}/>
          <input type="password" placeholder="Password" value={pass} onChange={e=>{setPass(e.target.value);setErr(false);}} onKeyDown={e=>e.key==="Enter"&&go()} style={inp}
            onFocus={e=>e.target.style.borderColor=c.tx} onBlur={e=>e.target.style.borderColor=err?"#ef4444":c.inpBd}/>
          {err&&<p style={{color:"#ef4444",fontSize:13,margin:"0 2px",letterSpacing:"-0.1px"}}>{isNew?"Email already exists.":"Invalid email or password."}</p>}
          <button onClick={go}
            style={{background:c.ac,border:"none",color:c.af,padding:"12px",borderRadius:10,cursor:"pointer",fontSize:15,fontWeight:500,fontFamily:"inherit",marginTop:4,letterSpacing:"-0.2px",transition:"opacity 0.15s",boxShadow:"0 2px 8px "+c.shadow}}
            onMouseEnter={e=>e.currentTarget.style.opacity="0.88"}
            onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
            {isNew?"Create account":"Continue →"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Message actions ───────────────────────────────────────────────────────────
function MsgActions({msg,isUser,onRegen,onEdit,c}){
  const [show,setShow]=useState(false);
  const [cop,setCop]=useState(false);
  const doCopy=()=>{navigator.clipboard.writeText(msg.content);setCop(true);setTimeout(()=>setCop(false),2000);};
  const btn={
    background:"none",border:"1px solid "+c.bd,color:c.mt,
    padding:"3px 9px",borderRadius:6,cursor:"pointer",fontSize:11,
    fontFamily:"inherit",transition:"all 0.15s",letterSpacing:"-0.1px"
  };
  return(
    <div onMouseEnter={()=>setShow(true)} onMouseLeave={()=>setShow(false)}>
      <div style={{display:"flex",gap:5,marginTop:8,opacity:show?1:0,transition:"opacity 0.2s",height:26}}>
        <button onClick={doCopy} style={{...btn,color:cop?"#16a34a":c.mt}}
          onMouseEnter={e=>e.currentTarget.style.background=c.sf}
          onMouseLeave={e=>e.currentTarget.style.background="none"}>
          {cop?"✓":"📋"} {cop?"copied":"copy"}
        </button>
        {!isUser&&onRegen&&(
          <button onClick={onRegen} style={btn}
            onMouseEnter={e=>e.currentTarget.style.background=c.sf}
            onMouseLeave={e=>e.currentTarget.style.background="none"}>🔄 regen</button>
        )}
        {isUser&&onEdit&&(
          <button onClick={onEdit} style={btn}
            onMouseEnter={e=>e.currentTarget.style.background=c.sf}
            onMouseLeave={e=>e.currentTarget.style.background="none"}>✏️ edit</button>
        )}
      </div>
    </div>
  );
}

// ── Typing indicator ──────────────────────────────────────────────────────────
function Typing({c}){
  return(
    <div style={{display:"flex",gap:5,alignItems:"center",padding:"4px 0"}}>
      {[0,1,2].map(n=>(
        <span key={n} style={{
          width:7,height:7,borderRadius:"50%",background:c.mt,display:"inline-block",
          animation:`typingDot 1.4s ${n*0.2}s ease-in-out infinite`
        }}/>
      ))}
    </div>
  );
}

// ── Main App ─────────────────────────────────────────────────────────────────
export default function App(){
  const [dark,setDark]           = useState(false);
  const [user,setUser]           = useState(null);
  const [msgs,setMsgs]           = useState([]);
  const [input,setInput]         = useState("");
  const [busy,setBusy]           = useState(false);
  const [srch,setSrch]           = useState("");
  const [apiKey,setApiKey]       = useState("");
  const [showKey,setShowKey]     = useState(false);
  const [showMenu,setShowMenu]   = useState(false);
  const [showHist,setShowHist]   = useState(false);
  const [hist,setHist]           = useState([]);
  const [sid,setSid]             = useState(null);
  const [files,setFiles]         = useState([]);
  const [mic,setMic]             = useState(false);
  const [webSearch,setWebSearch] = useState(true);
  const [sound,setSound]         = useState(true);
  const [editIdx,setEditIdx]     = useState(null);
  const [editVal,setEditVal]     = useState("");

  const c=dark?D:L;
  const endRef=useRef(null),taRef=useRef(null),fileRef=useRef(null),recRef=useRef(null);

  useEffect(()=>{endRef.current?.scrollIntoView({behavior:"smooth"});},[msgs,busy]);

  const resize=()=>{const el=taRef.current;if(!el)return;el.style.height="auto";el.style.height=Math.min(el.scrollHeight,180)+"px";};
  const addFiles=fs=>{const ok=Array.from(fs).filter(f=>isImg(f)||isPDF(f)||isCode(f));setFiles(p=>[...p,...ok].slice(0,5));};

  const startMic=()=>{
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return;
    if(mic){recRef.current?.stop();setMic(false);return;}
    const r=new SR();r.lang="en-US";r.continuous=false;r.interimResults=false;
    r.onresult=e=>{const t=e.results[0][0].transcript;setInput(p=>p?p+" "+t:t);setMic(false);setTimeout(resize,50);};
    r.onerror=r.onend=()=>setMic(false);
    recRef.current=r;r.start();setMic(true);
  };

  const saveSess=useCallback((messages,id)=>{
    if(!messages.length)return id;
    const s=id||Date.now().toString();
    setHist(prev=>{const ex=prev.find(x=>x.id===s);return ex?prev.map(x=>x.id===s?{...x,messages}:x):[{id:s,title:messages[0].content.slice(0,50),messages},...prev];});
    return s;
  },[]);

  const sendWith=useCallback(async(base,txt,fs)=>{
    if((!txt.trim()&&!fs.length)||busy)return;
    if(!apiKey){setShowKey(true);return;}
    const imgUrls=fs.filter(isImg).map(f=>URL.createObjectURL(f));
    const chips=fs.filter(f=>!isImg(f)).map(f=>({name:f.name,pdf:isPDF(f)}));
    const uMsg={role:"user",content:txt.trim()||(chips.length?"Analyze: "+chips.map(x=>x.name).join(", "):""),imgUrls,chips};
    const all=[...base,uMsg];
    setMsgs(all);setInput("");setFiles([]);setEditIdx(null);
    if(taRef.current)taRef.current.style.height="auto";
    setBusy(true);setSrch("");
    try{
      let uc;
      if(fs.length){
        uc=[];
        for(const f of fs){
          if(isImg(f))uc.push({type:"image",source:{type:"base64",media_type:f.type,data:await toB64(f)}});
          else if(isPDF(f))uc.push({type:"document",source:{type:"base64",media_type:"application/pdf",data:await toB64(f)}});
          else if(isCode(f))uc.push({type:"text",text:"```"+f.name+"\n"+(await toTxt(f))+"\n```"});
        }
        uc.push({type:"text",text:txt.trim()||"Analyze."});
      }else uc=txt.trim();
      const apiMsgs=[...base.map(m=>({role:m.role,content:m.content})),{role:"user",content:uc}];
      const body={model:"claude-sonnet-4-20250514",max_tokens:1024,system:SYSTEM,messages:apiMsgs};
      if(webSearch)body.tools=[{type:"web_search_20250305",name:"web_search"}];
      const call=async m2=>{const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","x-api-key":apiKey,"anthropic-version":"2023-06-01"},body:JSON.stringify({...body,messages:m2})});if(!r.ok)throw new Error("API "+r.status);return r.json();};
      let data=await call(apiMsgs),loop=[...apiMsgs],fullText="",sq="";
      while(true){
        for(const b of data.content||[]){
          if(b.type==="text")fullText+=b.text;
          if(b.type==="tool_use"&&b.name==="web_search"){sq=b.input?.query||"";setSrch(sq);}
        }
        if(data.stop_reason==="tool_use"&&webSearch){
          loop.push({role:"assistant",content:data.content});
          loop.push({role:"user",content:data.content.filter(b=>b.type==="tool_use").map(b=>({type:"tool_result",tool_use_id:b.id,content:"Done."}))});
          data=await call(loop);setSrch("");
        }else break;
      }
      setSrch("");
      const next=[...all,{role:"assistant",content:fullText||"…",sq}];
      setMsgs(next);setSid(saveSess(next,sid));
      if(sound)playBeep();
    }catch(e){setMsgs(p=>[...p,{role:"assistant",content:"**Error:** "+e.message}]);}
    finally{setBusy(false);setSrch("");}
  },[busy,apiKey,webSearch,sound,sid,saveSess]);

  const send=()=>sendWith(msgs,input,files);
  const regen=useCallback(()=>{
    if(busy||!msgs.length)return;
    const lastU=[...msgs].reverse().findIndex(m=>m.role==="user");
    if(lastU===-1)return;
    const idx=msgs.length-1-lastU;
    sendWith(msgs.slice(0,idx),msgs[idx].content,[]);
  },[msgs,busy,sendWith]);

  const submitEdit=()=>{if(!editVal.trim()||editIdx===null)return;sendWith(msgs.slice(0,editIdx),editVal,[]);};
  const exportChat=()=>{if(!msgs.length)return;const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([msgs.map(m=>(m.role==="user"?"You":"IT²")+": "+m.content).join("\n\n")],{type:"text/plain"}));a.download="IT2-chat.txt";a.click();};
  const shareChat=async()=>{const t=msgs.map(m=>(m.role==="user"?"You":"IT²")+": "+m.content).join("\n\n");if(navigator.share)await navigator.share({title:"IT² Chat",text:t});else{await navigator.clipboard.writeText(t);alert("Chat copied!");}};

  const onKey=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}};
  const newChat=()=>{setMsgs([]);setSid(null);setInput("");setFiles([]);setShowMenu(false);setEditIdx(null);};
  const logout=()=>{setUser(null);newChat();};

  if(!user)return <Login onLogin={setUser} c={c}/>;

  const menuItems=[
    {icon:"💬",label:"Chat history",   action:()=>{setShowHist(true);setShowMenu(false);}},
    {icon:"✏️",label:"New chat",       action:newChat},
    {icon:"📤",label:"Export",         action:()=>{exportChat();setShowMenu(false);}},
    {icon:"🔗",label:"Share",          action:()=>{shareChat();setShowMenu(false);}},
    {icon:"🔑",label:"API key",        action:()=>{setShowKey(v=>!v);setShowMenu(false);}},
    {icon:"🌐",label:(webSearch?"✅ ":"⬜ ")+"Web search",action:()=>{setWebSearch(v=>!v);setShowMenu(false);}},
    {icon:"🔔",label:(sound?"✅ ":"⬜ ")+"Sound",       action:()=>{setSound(v=>!v);setShowMenu(false);}},
    {icon:dark?"☀️":"🌙",label:dark?"Light":"Dark mode", action:()=>{setDark(v=>!v);setShowMenu(false);}},
    {icon:"⏻", label:"Sign out",       action:logout,danger:true},
  ];

  return(
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html,body,#root{height:100%}
        body{
          background:${c.bg};
          font-family:'Inter',-apple-system,sans-serif;
          -webkit-font-smoothing:antialiased;
          color:${c.tx};
          letter-spacing:-0.15px;
        }
        textarea{font-family:inherit!important;color:${c.tx}!important;letter-spacing:-0.15px!important}
        textarea::placeholder{color:${c.mt}!important}
        button:focus,input:focus,textarea:focus{outline:none}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-thumb{background:${c.bd};border-radius:4px}

        @keyframes slideUp{
          from{opacity:0;transform:translateY(20px)}
          to{opacity:1;transform:translateY(0)}
        }
        @keyframes fadeIn{
          from{opacity:0;transform:translateY(6px)}
          to{opacity:1;transform:translateY(0)}
        }
        @keyframes menuSlide{
          from{opacity:0;transform:translateY(-8px) scale(0.97)}
          to{opacity:1;transform:translateY(0) scale(1)}
        }
        @keyframes sidebarSlide{
          from{opacity:0;transform:translateX(-100%)}
          to{opacity:1;transform:translateX(0)}
        }
        @keyframes typingDot{
          0%,60%,100%{transform:translateY(0);opacity:0.4}
          30%{transform:translateY(-5px);opacity:1}
        }
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes micPulse{0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,0.4)}50%{box-shadow:0 0 0 6px rgba(239,68,68,0)}}
        @keyframes shimmer{0%{opacity:0.5}50%{opacity:1}100%{opacity:0.5}}
      `}</style>

      {showMenu&&<div onClick={()=>setShowMenu(false)} style={{position:"fixed",inset:0,zIndex:30}}/>}

      {/* ── Sidebar ── */}
      {showHist&&(
        <>
          <div onClick={()=>setShowHist(false)} style={{position:"fixed",inset:0,zIndex:40,background:"rgba(0,0,0,0.15)",backdropFilter:"blur(2px)"}}/>
          <div style={{position:"fixed",left:0,top:0,bottom:0,width:"min(300px,88vw)",background:c.sf,borderRight:"1px solid "+c.bd,zIndex:50,display:"flex",flexDirection:"column",animation:"sidebarSlide 0.25s cubic-bezier(0.16,1,0.3,1)",boxShadow:"4px 0 24px "+c.shadow}}>
            <div style={{padding:"14px 16px",borderBottom:"1px solid "+c.bd,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
              <span style={{fontSize:14,fontWeight:600,color:c.tx,letterSpacing:"-0.3px"}}>Chat History</span>
              <button onClick={()=>setShowHist(false)} style={{background:"none",border:"none",color:c.mt,cursor:"pointer",fontSize:18,lineHeight:1,padding:"2px 4px",borderRadius:6,transition:"color 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.color=c.tx}
                onMouseLeave={e=>e.currentTarget.style.color=c.mt}>✕</button>
            </div>
            <div style={{flex:1,overflowY:"auto",padding:"8px"}}>
              {hist.length===0
                ?<div style={{padding:"40px 16px",color:c.mt,fontSize:14,textAlign:"center",letterSpacing:"-0.2px"}}>No chats yet</div>
                :hist.map(s=>(
                  <div key={s.id} onClick={()=>{setMsgs(s.messages);setSid(s.id);setShowHist(false);}}
                    style={{padding:"10px 12px",borderRadius:9,cursor:"pointer",marginBottom:2,background:s.id===sid?c.bg:"transparent",display:"flex",alignItems:"center",gap:10,border:"1px solid "+(s.id===sid?c.bd:"transparent"),transition:"all 0.15s"}}
                    onMouseEnter={e=>{if(s.id!==sid){e.currentTarget.style.background=c.bg;}}}
                    onMouseLeave={e=>{if(s.id!==sid){e.currentTarget.style.background="transparent";}}}>
                    <span style={{fontSize:15}}>💬</span>
                    <div style={{flex:1,minWidth:0,fontSize:13,color:c.s2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",letterSpacing:"-0.2px"}}>{s.title}</div>
                    <button onClick={e=>{e.stopPropagation();setHist(p=>p.filter(x=>x.id!==s.id));if(sid===s.id)newChat();}}
                      style={{background:"none",border:"none",color:"transparent",fontSize:13,padding:"2px 4px",cursor:"pointer",borderRadius:4,transition:"color 0.15s"}}
                      onMouseEnter={e=>e.currentTarget.style.color="#ef4444"}
                      onMouseLeave={e=>e.currentTarget.style.color="transparent"}>✕</button>
                  </div>
                ))
              }
            </div>
            <div style={{padding:"14px 16px",borderTop:"1px solid "+c.bd,display:"flex",alignItems:"center",gap:12}}>
              <div style={{width:32,height:32,borderRadius:10,background:c.ac,display:"flex",alignItems:"center",justifyContent:"center",color:c.af,fontSize:13,fontWeight:600,flexShrink:0,letterSpacing:"-0.3px"}}>{user.name[0].toUpperCase()}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:13,fontWeight:500,color:c.tx,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",letterSpacing:"-0.2px"}}>{user.name}</div>
                <div style={{fontSize:11,color:c.mt,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.email}</div>
              </div>
              <button onClick={logout} style={{background:"none",border:"none",color:c.mt,fontSize:16,cursor:"pointer",padding:"4px",borderRadius:6,transition:"color 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.color="#ef4444"}
                onMouseLeave={e=>e.currentTarget.style.color=c.mt}>⏻</button>
            </div>
          </div>
        </>
      )}

      <input ref={fileRef} type="file" multiple accept="image/*,.pdf,.py,.js,.ts,.jsx,.tsx,.java,.c,.cpp,.go,.sql,.json,.html,.css,.txt,.csv" style={{display:"none"}} onChange={e=>{addFiles(e.target.files);e.target.value="";}}/>

      {/* ── Layout ── */}
      <div style={{height:"100dvh",display:"flex",flexDirection:"column",background:c.bg}}
        onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();addFiles(e.dataTransfer.files);}}>

        {/* ── Header ── */}
        <header style={{padding:"12px 18px",display:"flex",alignItems:"center",justifyContent:"space-between",borderBottom:"1px solid "+c.bd,flexShrink:0,backdropFilter:"blur(8px)",background:c.bg+"ee"}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:30,height:30,borderRadius:9,background:c.ac,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 2px 6px "+c.shadow}}>
              <span style={{color:c.af,fontSize:11,fontWeight:700,fontFamily:"'JetBrains Mono',monospace",letterSpacing:"-0.5px"}}>IT²</span>
            </div>
            {webSearch&&<span style={{fontSize:11,color:c.mt,background:c.sf,border:"1px solid "+c.bd,borderRadius:5,padding:"2px 7px",letterSpacing:"-0.1px"}}>🌐 web</span>}
          </div>

          <div style={{position:"relative"}}>
            <button onClick={()=>setShowMenu(v=>!v)}
              style={{background:"none",border:"1px solid "+(showMenu?c.bd:"transparent"),color:c.mt,width:36,height:36,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:18,letterSpacing:"2px",transition:"all 0.15s"}}
              onMouseEnter={e=>{e.currentTarget.style.background=c.sf;e.currentTarget.style.borderColor=c.bd;}}
              onMouseLeave={e=>{if(!showMenu){e.currentTarget.style.background="none";e.currentTarget.style.borderColor="transparent";}}}>⋯</button>

            {showMenu&&(
              <div style={{position:"absolute",right:0,top:"calc(100% + 8px)",width:220,background:c.sf,border:"1px solid "+c.bd,borderRadius:12,boxShadow:"0 12px 36px "+c.shadow,zIndex:50,overflow:"hidden",animation:"menuSlide 0.18s cubic-bezier(0.16,1,0.3,1)"}}>
                <div style={{padding:"13px 15px 11px",borderBottom:"1px solid "+c.bd,display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:32,height:32,borderRadius:9,background:c.ac,display:"flex",alignItems:"center",justifyContent:"center",color:c.af,fontSize:13,fontWeight:600,flexShrink:0}}>{user.name[0].toUpperCase()}</div>
                  <div style={{minWidth:0}}>
                    <div style={{fontSize:13,fontWeight:500,color:c.tx,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",letterSpacing:"-0.2px"}}>{user.name}</div>
                    <div style={{fontSize:11,color:c.mt,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.email}</div>
                  </div>
                </div>
                <div style={{padding:"6px"}}>
                  {menuItems.map((item,i)=>(
                    <button key={i} onClick={item.action}
                      style={{width:"100%",background:"none",border:"none",padding:"9px 11px",borderRadius:8,cursor:"pointer",display:"flex",alignItems:"center",gap:10,fontSize:13,color:item.danger?"#ef4444":c.tx,textAlign:"left",fontFamily:"inherit",transition:"background 0.12s",letterSpacing:"-0.2px"}}
                      onMouseEnter={e=>e.currentTarget.style.background=c.bg}
                      onMouseLeave={e=>e.currentTarget.style.background="none"}>
                      <span style={{fontSize:15,width:20,textAlign:"center"}}>{item.icon}</span>
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </header>

        {/* ── API Key ── */}
        {showKey&&(
          <div style={{padding:"10px 18px",borderBottom:"1px solid "+c.bd,display:"flex",gap:8,background:c.sf,flexShrink:0,animation:"fadeIn 0.2s ease"}}>
            <input type="password" placeholder="Paste your sk-ant-… key" value={apiKey} onChange={e=>setApiKey(e.target.value)} onKeyDown={e=>e.key==="Enter"&&setShowKey(false)} autoFocus
              style={{flex:1,background:c.inp,border:"1px solid "+c.inpBd,borderRadius:8,padding:"8px 12px",color:c.tx,fontSize:13,fontFamily:"'JetBrains Mono',monospace",letterSpacing:"-0.2px"}}/>
            <button onClick={()=>setShowKey(false)} style={{background:c.ac,border:"none",color:c.af,width:36,borderRadius:8,cursor:"pointer",fontSize:15,fontWeight:500,transition:"opacity 0.15s"}}
              onMouseEnter={e=>e.currentTarget.style.opacity="0.85"}
              onMouseLeave={e=>e.currentTarget.style.opacity="1"}>✓</button>
          </div>
        )}

        {/* ── Messages ── */}
        <main style={{flex:1,overflowY:"auto",scrollBehavior:"smooth"}}>

          {msgs.length===0&&!busy&&(
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"60vh",gap:12,animation:"fadeIn 0.4s ease"}}>
              <div style={{width:52,height:52,borderRadius:15,background:c.sf,border:"1px solid "+c.bd,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 4px 16px "+c.shadow}}>
                <span style={{color:c.mt,fontSize:18,fontWeight:700,fontFamily:"'JetBrains Mono',monospace",letterSpacing:"-0.5px"}}>IT²</span>
              </div>
              <p style={{fontSize:14,color:c.mt,letterSpacing:"-0.2px"}}>Ask me anything to get started</p>
              {!apiKey&&<p style={{fontSize:12,color:c.mt,opacity:0.7,letterSpacing:"-0.1px"}}>Click ⋯ → API key to set your key</p>}
            </div>
          )}

          {msgs.map((m,i)=>{
            const isU=m.role==="user";
            const isEditing=editIdx===i;
            return(
              <div key={i} style={{padding:"20px 18px",borderBottom:"1px solid "+c.bd,background:isU?c.msgUser:c.msgAI,animation:"fadeIn 0.22s cubic-bezier(0.16,1,0.3,1)"}}>
                <div style={{maxWidth:700,margin:"0 auto",display:"flex",gap:12,alignItems:"flex-start"}}>

                  {/* Avatar */}
                  <div style={{width:26,height:26,borderRadius:8,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",background:isU?c.sf:c.ac,color:isU?c.s2:c.af,fontSize:10,fontWeight:600,border:isU?"1px solid "+c.bd:"none",marginTop:2,fontFamily:"'JetBrains Mono',monospace",letterSpacing:"-0.5px",boxShadow:isU?"none":"0 1px 4px "+c.shadow}}>
                    {isU?user.name[0].toUpperCase():"IT²"}
                  </div>

                  <div style={{flex:1,minWidth:0}}>
                    {m.imgUrls&&m.imgUrls.map((url,j)=>(
                      <img key={j} src={url} alt="" style={{maxWidth:"min(280px,80vw)",borderRadius:10,marginBottom:10,border:"1px solid "+c.bd,display:"block",boxShadow:"0 2px 8px "+c.shadow}}/>
                    ))}
                    {m.chips&&m.chips.map((f,j)=>(
                      <span key={j} style={{display:"inline-flex",alignItems:"center",gap:5,background:c.sf,border:"1px solid "+c.bd,borderRadius:6,padding:"3px 10px",fontSize:12,color:c.mt,marginBottom:6,marginRight:5,letterSpacing:"-0.1px"}}>
                        {f.pdf?"📄":"💻"} {f.name}
                      </span>
                    ))}
                    {m.sq&&<div style={{fontSize:11,color:c.mt,marginBottom:7,letterSpacing:"-0.1px"}}>🔍 <em>{m.sq}</em></div>}

                    {isEditing?(
                      <div style={{display:"flex",flexDirection:"column",gap:8}}>
                        <textarea value={editVal} onChange={e=>setEditVal(e.target.value)} autoFocus
                          style={{background:c.inp,border:"1px solid "+c.ac,borderRadius:10,padding:"10px 14px",color:c.tx,fontSize:15,resize:"none",fontFamily:"inherit",lineHeight:1.7,minHeight:70,outline:"none",letterSpacing:"-0.15px"}}/>
                        <div style={{display:"flex",gap:7}}>
                          <button onClick={submitEdit} style={{background:c.ac,border:"none",color:c.af,padding:"6px 16px",borderRadius:8,cursor:"pointer",fontSize:13,fontFamily:"inherit",fontWeight:500,letterSpacing:"-0.2px",transition:"opacity 0.15s"}}
                            onMouseEnter={e=>e.currentTarget.style.opacity="0.85"}
                            onMouseLeave={e=>e.currentTarget.style.opacity="1"}>Send ↑</button>
                          <button onClick={()=>setEditIdx(null)} style={{background:"none",border:"1px solid "+c.bd,color:c.mt,padding:"6px 16px",borderRadius:8,cursor:"pointer",fontSize:13,fontFamily:"inherit",letterSpacing:"-0.2px",transition:"all 0.15s"}}
                            onMouseEnter={e=>e.currentTarget.style.background=c.sf}
                            onMouseLeave={e=>e.currentTarget.style.background="none"}>Cancel</button>
                        </div>
                      </div>
                    ):(
                      <>
                        <div style={{fontSize:15,lineHeight:1.85,letterSpacing:"-0.15px"}}>
                          {isU
                            ?<p style={{margin:0,whiteSpace:"pre-wrap",color:c.tx}}>{m.content}</p>
                            :<MD text={m.content} c={c}/>
                          }
                        </div>
                        <MsgActions msg={m} isUser={isU} c={c}
                          onRegen={!isU&&i===msgs.length-1&&!busy?regen:null}
                          onEdit={isU?()=>{setEditIdx(i);setEditVal(m.content);}:null}/>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Busy / Search */}
          {(srch||(busy&&!srch))&&(
            <div style={{padding:"20px 18px",background:c.msgAI,borderBottom:"1px solid "+c.bd,animation:"fadeIn 0.2s ease"}}>
              <div style={{maxWidth:700,margin:"0 auto",display:"flex",gap:12,alignItems:"flex-start"}}>
                <div style={{width:26,height:26,borderRadius:8,background:c.ac,display:"flex",alignItems:"center",justifyContent:"center",color:c.af,fontSize:10,fontWeight:600,flexShrink:0,fontFamily:"'JetBrains Mono',monospace",letterSpacing:"-0.5px",boxShadow:"0 1px 4px "+c.shadow}}>IT²</div>
                <div style={{paddingTop:4}}>
                  {srch
                    ?<div style={{display:"flex",alignItems:"center",gap:8}}>
                        <span style={{fontSize:13,color:c.mt,animation:"spin 1.2s linear infinite",display:"inline-block"}}>◌</span>
                        <span style={{fontSize:12,color:c.mt,letterSpacing:"-0.1px"}}>Searching: <em>{srch}</em></span>
                      </div>
                    :<Typing c={c}/>
                  }
                </div>
              </div>
            </div>
          )}
          <div ref={endRef}/>
        </main>

        {/* ── Input ── */}
        <footer style={{padding:"10px 18px 18px",background:c.bg,borderTop:"1px solid "+c.bd,flexShrink:0}}>
          <div style={{maxWidth:700,margin:"0 auto"}}>

            {/* File chips */}
            {files.length>0&&(
              <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:8,animation:"fadeIn 0.2s ease"}}>
                {files.map((f,i)=>(
                  <div key={i} style={{display:"inline-flex",alignItems:"center",gap:6,background:c.sf,border:"1px solid "+c.bd,borderRadius:8,padding:"4px 10px",fontSize:12,color:c.s2,boxShadow:"0 1px 3px "+c.shadow}}>
                    {isImg(f)?<img src={URL.createObjectURL(f)} alt="" style={{width:18,height:18,borderRadius:4,objectFit:"cover"}}/>:<span>{isPDF(f)?"📄":"💻"}</span>}
                    <span style={{maxWidth:90,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",fontSize:11,color:c.mt,letterSpacing:"-0.1px"}}>{f.name}</span>
                    <button onClick={()=>setFiles(p=>p.filter((_,j)=>j!==i))} style={{background:"none",border:"none",color:c.mt,fontSize:13,padding:0,cursor:"pointer",lineHeight:1,transition:"color 0.15s"}}
                      onMouseEnter={e=>e.currentTarget.style.color="#ef4444"}
                      onMouseLeave={e=>e.currentTarget.style.color=c.mt}>✕</button>
                  </div>
                ))}
              </div>
            )}

            {/* Input box */}
            <div style={{border:"1px solid "+c.inpBd,borderRadius:14,background:c.inp,padding:"10px 10px 10px 14px",display:"flex",alignItems:"flex-end",gap:7,transition:"border-color 0.2s, box-shadow 0.2s",boxShadow:"0 2px 8px "+c.shadow}}
              onFocusCapture={e=>{e.currentTarget.style.borderColor=c.tx;e.currentTarget.style.boxShadow="0 4px 16px "+c.shadow;}}
              onBlurCapture={e=>{e.currentTarget.style.borderColor=c.inpBd;e.currentTarget.style.boxShadow="0 2px 8px "+c.shadow;}}>

              {/* Attach */}
              <button onClick={()=>fileRef.current?.click()}
                style={{background:"none",border:"none",color:c.mt,width:30,height:30,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:20,borderRadius:7,transition:"all 0.15s"}}
                onMouseEnter={e=>{e.currentTarget.style.color=c.tx;e.currentTarget.style.background=c.sf;}}
                onMouseLeave={e=>{e.currentTarget.style.color=c.mt;e.currentTarget.style.background="none";}}>＋</button>

              {/* Mic */}
              <button onClick={startMic}
                style={{background:mic?"#ef4444":"none",border:"1px solid "+(mic?"#ef4444":c.inpBd),color:mic?"#fff":c.mt,width:30,height:30,borderRadius:7,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:13,transition:"all 0.2s",animation:mic?"micPulse 1.5s infinite":"none"}}>🎤</button>

              {/* Textarea */}
              <textarea ref={taRef} rows={1} placeholder="Ask anything…" value={input}
                onChange={e=>{setInput(e.target.value);resize();}} onKeyDown={onKey}
                style={{flex:1,background:"transparent",border:"none",fontSize:15,resize:"none",lineHeight:1.7,maxHeight:180,fontWeight:400,padding:0,color:c.tx,letterSpacing:"-0.15px"}}/>

              {/* Send */}
              <button onClick={send} disabled={busy||(!input.trim()&&!files.length)}
                style={{width:32,height:32,borderRadius:8,border:"none",flexShrink:0,
                  background:(!input.trim()&&!files.length)||busy?c.sf:c.ac,
                  color:(!input.trim()&&!files.length)||busy?c.mt:c.af,
                  display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,
                  transition:"all 0.18s",cursor:busy||(!input.trim()&&!files.length)?"default":"pointer",
                  boxShadow:(!input.trim()&&!files.length)||busy?"none":"0 2px 8px "+c.shadow}}
                onMouseEnter={e=>{if(input.trim()||files.length)e.currentTarget.style.opacity="0.85";}}
                onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                {busy
                  ?<span style={{width:12,height:12,border:"2px solid transparent",borderTopColor:c.mt,borderRadius:"50%",animation:"spin 0.7s linear infinite",display:"inline-block"}}/>
                  :"↑"
                }
              </button>
            </div>

            <p style={{textAlign:"center",fontSize:11,color:c.mt,marginTop:8,letterSpacing:"-0.1px",opacity:0.7}}>
              IT² can make mistakes. Verify important info.
            </p>
          </div>
        </footer>
      </div>
    </>
  );
}
